# Spencer Macro Client
An open-source, Cross-Platform Windows + Linux C++ Roblox ImGui Macro with many features.

To compile, run the project in Visual Studio 2022 and build it. The main source code is located inside of Visual Studio/macroframework.cpp. It is intended to be compiled through windows
To compile the linux helper binary, there is a separate source code folder inside the Resource Files folder. Compile this with g++.

### Is this A CHEAT???
No, it's a macro, it doesn't communicate with Roblox memory in any way.

### Known Issues
- If you get "0x0" or any other key immediately when binding, restart your PC.

- If you get DLL errors when launching, install [The Visual Studio 2022 x64 C++ Redist](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist).

- If it doesn't launch at all in Windows, go into properties and select "Unblock" on the file.

- If you have another issue where keybinds don't work, restart your computer, and it seems to fix it permanently.

- In certain scenarios, when downgrading from a version with more features to a version with fewer features causes the program to crash on launch, either delete your RMCsettings.json file, or remove section_order_vector from the .json.

![GitHub Releases](https://img.shields.io/github/downloads/Spencer0187/Spencer-Macro-Utilities/total.svg)

## [Link to Latest Version](https://github.com/Spencer0187/Spencer-Macro-Utilities/releases/latest)
- Windows Installation: Run the executable "suspend" file.
- Linux Installation: Run the executable "suspend" file through [Wine](https://gitlab.winehq.org/wine/wine/-/wikis/Download), and accept the Admin Confirmation. Works across nearly all distros.
(Zenity must be installed on Linux to launch, run `sudo apt-get install zenity` or equivalent command)

## Join the Roblox Glitching Discord! (I can help you with support)
https://discord.gg/roblox-glitching-community-998572881892094012

# Current Features (Fully explained in-program):

1. Anti-AFK at all times (even if Roblox isn't shown)
2. Customizable UI buttons (Drag to Swap Locations)
3. Helicopter High Jump
4. Speedglitch
5. Automatic Ledge Bouncing
6. Automatic Laugh Clipping
7. Dropless Item Desync Hitboxes
8. Freeze Macro
9. Unequip Speedglitch
10. Wallhop Macro
11. Walless Lag High Jump (14 Studs)
12. Press a Key for One Frame
13. Wall-Walk
14. Item-Clip
15. Spam a Key/Button
16. Intelligent Bhop/Bunnyhop

# AUTOMATICALLY SAVES YOUR SETTINGS WHEN CLOSED

## The UI is customizable, drag your buttons to re-order them

<img width="1694" height="963" alt="image" src="https://github.com/user-attachments/assets/80d843de-4141-4cc4-8cc0-42676c0a2662" />

<img width="1690" height="960" alt="image" src="https://github.com/user-attachments/assets/0bf81cba-2444-4454-952b-17ea7a1db4a5" />

<img width="1691" height="963" alt="image" src="https://github.com/user-attachments/assets/c6423c05-9fec-4b27-bd1b-7deea39fa222" />

https://github.com/user-attachments/assets/a2c63feb-b947-4247-802c-34bf6cf8c2ce

## Code Signing Policy

This project uses free code signing provided by [SignPath.io](https://about.signpath.io/), with certificates issued by [SignPath Foundation](https://signpath.org/).

| [<img src="https://avatars.githubusercontent.com/u/34448643?s=25&v=4" width="25">](https://about.signpath.io/) | Free code signing provided by [**SignPath.io**](https://about.signpath.io/), certificate by [**SignPath Foundation**](https://signpath.org/) |
|----------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------|

## Debugging Instructions
  (To show printed messages)
  - Windows: Open Command Prompt in the directory of suspend.exe, run `set DEBUG=1`, and then run suspend.exe within Command Prompt.
  - Linux: Run using `DEBUG=1 wine suspend.exe`.  

### Team Roles
- **Committer and Approver**: [Project Owner (Spencer)](https://github.com/Spencer0187/)

### Privacy Policy
This application makes client-side HTTP requests solely for version checking and updates. No user data is collected or transmitted to any servers.

## Credits

- Freezing code framework based on [craftwar/suspend](https://github.com/craftwar/suspend)
- ImGui GUI library used, obviously... [ocornut/imgui](https://github.com/ocornut/imgui)
